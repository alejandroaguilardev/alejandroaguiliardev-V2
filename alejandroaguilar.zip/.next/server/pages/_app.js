"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 9822:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ ModeContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const INIT = {
    theme: {
        mode: false
    },
    handleTheme: ()=>{
        false;
    }
};
const ModeContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(INIT);


/***/ }),

/***/ 2140:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/context/mode/ModeContext.tsx
var ModeContext = __webpack_require__(9822);
;// CONCATENATED MODULE: ./src/context/mode/ModeReducer.ts
const ModeReducer = (state, action)=>{
    switch(action.type){
        case "changeMode":
            return {
                ...state,
                mode: action.payload.mode
            };
        default:
            return state;
    }
};

;// CONCATENATED MODULE: ./src/context/mode/ModeProvider.tsx




const INIT = {
    mode: false
};
const ModeProvider = ({ children  })=>{
    const { 0: theme , 1: dispatch  } = (0,external_react_.useReducer)(ModeReducer, INIT);
    const handleTheme = (mode)=>{
        dispatch({
            type: "changeMode",
            payload: {
                mode
            }
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(ModeContext/* ModeContext.Provider */.Q.Provider, {
        value: {
            theme,
            handleTheme
        },
        children: children
    });
};

;// CONCATENATED MODULE: ./src/pages/_app.tsx



function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(ModeProvider, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
            ...pageProps
        })
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2140));
module.exports = __webpack_exports__;

})();