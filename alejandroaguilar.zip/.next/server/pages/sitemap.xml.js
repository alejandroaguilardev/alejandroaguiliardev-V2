"use strict";
(() => {
var exports = {};
exports.id = 164;
exports.ids = [164];
exports.modules = {

/***/ 4346:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
function SiteMap() {
    generateSiteMap();
}
function generateSiteMap() {
    return `<?xml version="1.0" encoding="UTF-8"?>
	<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
		<!--We manually set the two URLs we know already-->
		<url>
			<loc>https://alejandroaguilar.dev/</loc>
		</url>
		<url>
			<loc>https://alejandroaguilar.dev/about</loc>
		</url>
		<url>
			<loc>https://alejandroaguilar.dev/skills</loc>
		</url>
		<url>
			<loc>https://alejandroaguilar.dev/project</loc>
		</url>
   </urlset>
 `;
}
async function getServerSideProps({ res  }) {
    const sitemap = generateSiteMap();
    res.setHeader("Content-Type", "text/xml");
    res.write(sitemap);
    res.end();
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SiteMap);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4346));
module.exports = __webpack_exports__;

})();