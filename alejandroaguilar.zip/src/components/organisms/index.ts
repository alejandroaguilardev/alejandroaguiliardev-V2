export * from "./About/About";
export * from "./ContainerSocialNetworks/ContainerSocialNetworks";
export * from "./Education/Education";
export * from "./Experience/Experience";
export * from "./Footer/Footer";
export * from "./Navbar/Navbar";
export * from "./Projects/Projects";
export * from "./Skills/Skills";
