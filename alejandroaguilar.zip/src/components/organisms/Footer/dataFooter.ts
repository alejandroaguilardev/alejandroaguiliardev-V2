export const dataBriefcase = [
	{ title: "Design" },
	{ title: "Front End" },
	{ title: "Back End" },
	{ title: "Smart Contract" },
];

export const dataInformation = [
	{ title: "E-mail", secondary: "hello@alejandroaguilar.dev", type: "text" },
	{ title: "Security Politics", secondary: "", type: "link" },
	{ title: "Terms and Conditions", secondary: "", type: "link" },
];
