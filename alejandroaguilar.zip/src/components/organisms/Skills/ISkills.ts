export interface ISkills {
	title: string;
	description: string;
	dataSkills: {
		title: string;
		subtitle: string;
		description: string;
		icon: string;
	}[];
}
