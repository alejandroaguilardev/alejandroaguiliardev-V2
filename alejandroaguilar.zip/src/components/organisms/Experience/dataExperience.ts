export const dataExperience = [
	{
		title: "QOLKREX FOUNDATION",
		subtitle: "BLOCKCHAIN DEVELOPER",
		description:
			"Foundation that promotes Blockchain research and development in Peru.",
		icon: "/img/experiences/qolkrex.png",
	},
	{
		title: "MEDIWEB",
		subtitle: "DEVELOPER FULL STACK",
		description:
			"Company specialized in solutions for clinics in order to provide comprehensive management of the operations they perform.",
		icon: "/img/experiences/mediweb.png",
	},
	{
		title: "GWEB7",
		subtitle: "DEVELOPER FRONT END",
		description:
			"Marketing agency that offers multiple quality services with creativity.",
		icon: "/img/experiences/gweb7.png",
	},
];
