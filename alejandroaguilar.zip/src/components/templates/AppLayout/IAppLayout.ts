export interface IAppLayout {
    children: React.ReactNode;
    title: string;
    description: string;
    page:string;
}