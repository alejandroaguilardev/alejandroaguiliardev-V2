import { IDataGalleryEducation } from "../../../data/dataGalleryEducation";

export interface IImageListGallery {
	dataImage: IDataGalleryEducation[];
}
