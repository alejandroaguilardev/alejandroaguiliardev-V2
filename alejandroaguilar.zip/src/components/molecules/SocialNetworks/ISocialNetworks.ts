export interface IISocialNetworks {
    fab?:boolean;
}