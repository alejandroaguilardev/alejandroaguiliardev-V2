export interface ICardImage {
	title:string;
	icon:string;
	size:string;
	link:string;
	repository:string;
}
