export interface IMenu {
    pages: string[];
    menu: boolean;
    setMenu: (menu: boolean) => void;
}