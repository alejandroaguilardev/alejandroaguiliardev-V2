export interface IMenuResponsive {
    pages: string[];
    menu: boolean;
}