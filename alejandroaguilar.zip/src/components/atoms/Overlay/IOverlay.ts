import { ReactNode } from "react";

export interface IOverlay {
	children: ReactNode;
}
