export interface ILogotype {
    ligth?:boolean;
}