import { ReactNode } from "react";

export interface ISection {
	children: ReactNode;
}
