import React from "react";

export interface INetworks {
	children: React.ReactNode;
	title: string;
    text:string;
    fab:boolean;
}
