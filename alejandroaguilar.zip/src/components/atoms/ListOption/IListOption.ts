export interface IListOption {
	title: string;
	list: { title: string; secondary?: string; type?: string }[];
}
