import { ReactNode } from "react";

export interface IContentPaper {
	children: ReactNode;
}
