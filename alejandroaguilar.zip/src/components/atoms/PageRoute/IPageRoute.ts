export interface IPage {
    page:string;
    sx?:object;
}