export interface ICurriculum {
    text?:string;
    fullWidth?:boolean
    sx?:object
}