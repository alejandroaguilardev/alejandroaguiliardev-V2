export interface IMyButton {
	text: string;
}
