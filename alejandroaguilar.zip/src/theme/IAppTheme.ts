export interface IAppTheme {
    children: React.ReactNode;
}